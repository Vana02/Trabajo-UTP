
function saludar() {
    alert("Hola mundo desde Aceros Ortiz!");
}

function preguntarCompra() {
    let nombre = prompt("¿Cómo te llamas?");
    let producto = prompt("¿Qué te interesa comprar?");

    let confirmar = confirm("¿Deseas confirmar la compra de " + producto + "?");

    if (confirmar) {
        alert("Gracias " + nombre + ", tu compra de " + producto + " ha sido confirmada.");
    } else {
        alert("No te preocupes " + nombre + ", tu compra fue cancelada.");
    }
}

const titulo = document.getElementById('titulo-principal');
console.log(titulo.textContent);
titulo.textContent = "Calidad en Acero Inoxidable";


const finalSection = document.getElementById('final');
const nuevo = document.createElement('p');
nuevo.textContent = "Gracias por visitar Aceros Ortiz.";

finalSection.appendChild(nuevo);
